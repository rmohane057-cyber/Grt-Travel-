import React from 'react';
import logo from '../../public/assets/logo/logo-72.png'; // or import from src/assets

export default function AdminHeader() {
  return (
    <div style={{display: 'flex', alignItems: 'center', padding: 12}}>
      <img src={logo} alt="GrtTravel Logo" style={{width: 48, height: 48, marginRight: 12}} />
      <h1>GrtTravel Admin</h1>
    </div>
  );
}