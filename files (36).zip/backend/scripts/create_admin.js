// Usage: node scripts/create_admin.js admin@example.com 'Password123!'
const { Pool } = require('pg');
const bcrypt = require('bcrypt');

(async () => {
  const [,, email, plainPassword] = process.argv;
  if (!email || !plainPassword) {
    console.error('Usage: node scripts/create_admin.js email password');
    process.exit(1);
  }

  const pool = new Pool({ connectionString: process.env.DATABASE_URL || 'postgres://grt:grtpassword@localhost:5432/grttravel' });

  try {
    const hashed = await bcrypt.hash(plainPassword, 10);
    const res = await pool.query(
      `INSERT INTO users (id, email, password_hash, full_name, country, created_at)
       VALUES (gen_random_uuid(), $1, $2, $3, $4, now())
       RETURNING id`,
      [email, hashed, 'Admin User', 'IN']
    );
    console.log('Admin created with id', res.rows[0].id);
  } catch (err) {
    console.error('Error creating admin:', err);
  } finally {
    await pool.end();
  }
})();