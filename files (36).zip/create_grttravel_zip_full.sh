#!/usr/bin/env bash
# create_grttravel_zip_full.sh
# Produces GrtTravel repo scaffold, generates icon assets (ImageMagick required),
# and creates GrtTravel.zip. BEFORE running, place your source images in:
# ./assets/logo/source/image2.png  (primary)
# ./assets/logo/source/image3.png
# ./assets/logo/source/image4.png

set -e
ROOT="GrtTravel"
SRC_DIR="./assets/logo/source"
OUT_DIR="${ROOT}/assets/logo"
echo "Preparing to create ${ROOT} and GrtTravel.zip"

# Ensure prerequisites
command -v convert >/dev/null 2>&1 || { echo >&2 "ImageMagick 'convert' is required. Install it and retry."; exit 1; }
command -v zip >/dev/null 2>&1 || { echo >&2 "zip is required. Install it and retry."; exit 1; }

# Clean previous
rm -rf "${ROOT}" GrtTravel.zip
mkdir -p "${ROOT}"
mkdir -p "${SRC_DIR}"
mkdir -p "${OUT_DIR}"

# Check for required source images (user MUST put images here)
if [ ! -f "${SRC_DIR}/image2.png" ]; then
  echo "Please place your source images in ${SRC_DIR} as image2.png image3.png image4.png"
  echo "Aborting."
  exit 1
fi

# Create folder structure
mkdir -p ${ROOT}/{mobile-app,backend,admin-panel/src/pages,db,scripts,docs,.github/workflows}
mkdir -p ${ROOT}/admin-panel/public/assets/logo
mkdir -p ${ROOT}/assets/logo/source

# Copy source images into scaffold (so they are included in the zip)
cp "${SRC_DIR}/image2.png" "${ROOT}/assets/logo/source/image2.png"
if [ -f "${SRC_DIR}/image3.png" ]; then cp "${SRC_DIR}/image3.png" "${ROOT}/assets/logo/source/image3.png"; fi
if [ -f "${SRC_DIR}/image4.png" ]; then cp "${SRC_DIR}/image4.png" "${ROOT}/assets/logo/source/image4.png"; fi

# Write key scaffold files (concise starters)
cat > ${ROOT}/README.md <<'EOF'
# GrtTravel (scaffold bundle)

This archive contains:
- mobile-app/ (Expo)
- backend/ (Node + Express)
- admin-panel/ (React skeleton)
- db/ (schema + seeds)
- assets/logo/ (generated assets go here)
- scripts/ (asset generation + helpful utilities)
- docs/ (deploy & Play Store checklist)

Run scripts/generate-grt-assets.sh to generate icons (ImageMagick required).
EOF

# Mobile app minimal App.js
mkdir -p ${ROOT}/mobile-app/src
cat > ${ROOT}/mobile-app/App.js <<'EOF'
import React, { useEffect, useState } from 'react';
import { View, Text, Button } from 'react-native';
import * as Location from 'expo-location';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function App() {
  const [statusMsg, setStatusMsg] = useState('Preparing...');
  const [coords, setCoords] = useState(null);

  useEffect(() => {
    (async () => {
      const cached = await AsyncStorage.getItem('cached_location');
      if (cached) {
        const c = JSON.parse(cached);
        setCoords(c);
        setStatusMsg(\`Using cached location: \${c.lat}, \${c.lng}\`);
        return;
      }
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setStatusMsg('Location permission denied. Please select city manually.');
        return;
      }
      const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      const payload = { lat: loc.coords.latitude, lng: loc.coords.longitude, ts: Date.now() };
      setCoords(payload);
      setStatusMsg('Location detected.');
      await AsyncStorage.setItem('cached_location', JSON.stringify(payload));
    })();
  }, []);

  return (
    <View style={{flex:1,justifyContent:'center',alignItems:'center',padding:20}}>
      <Text style={{marginBottom:10}}>{statusMsg}</Text>
      {coords && <Text>{\`Lat: \${coords.lat}  Lng: \${coords.lng}\`}</Text>}
      <Button title="Manual city selection" onPress={() => { /* navigate */ }} />
    </View>
  );
}
EOF

cat > ${ROOT}/mobile-app/package.json <<'EOF'
{
  "name": "grttravel-mobile",
  "version": "0.1.0",
  "private": true,
  "main": "node_modules/expo/AppEntry.js",
  "scripts": {
    "start": "expo start"
  },
  "dependencies": {
    "expo": "^48.0.0",
    "expo-location": "^15.0.0",
    "react": "18.2.0",
    "react-native": "0.71.8",
    "@react-native-async-storage/async-storage": "^1.17.0"
  }
}
EOF

cat > ${ROOT}/mobile-app/app.json <<'EOF'
{
  "expo": {
    "name": "GrtTravel",
    "slug": "grttravel",
    "version": "1.0.0",
    "icon": "../assets/logo/grt-192.png",
    "android": {
      "package": "com.grttravel.app",
      "adaptiveIcon": {
        "foregroundImage": "../assets/logo/android-foreground.png",
        "backgroundImage": "../assets/logo/android-background.png"
      },
      "permissions": ["ACCESS_FINE_LOCATION"]
    }
  }
}
EOF

# Backend minimal server
cat > ${ROOT}/backend/server.js <<'EOF'
const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch');
require('express-async-errors');

const app = express();
app.use(cors());
app.use(express.json());

app.get('/health', (req, res) => res.json({ ok: true }));

app.listen(process.env.PORT || 4000, () => console.log('Server started'));
EOF

cat > ${ROOT}/backend/package.json <<'EOF'
{
  "name": "grttravel-backend",
  "version": "0.1.0",
  "main": "server.js",
  "scripts": {
    "start": "node server.js"
  },
  "dependencies": {
    "cors": "^2.8.5",
    "express": "^4.18.2",
    "node-fetch": "^2.6.7",
    "express-async-errors": "^3.1.1"
  }
}
EOF

cat > ${ROOT}/backend/.env.example <<'EOF'
PORT=4000
DATABASE_URL=postgres://user:pass@host:5432/grttravel
JWT_SECRET=replace_with_strong_random
GOOGLE_MAPS_SERVER_KEY=REPLACE_ME
GOOGLE_MAPS_ANDROID_KEY=REPLACE_ME
EOF

# Admin placeholder
cat > ${ROOT}/admin-panel/src/pages/Dashboard.js <<'EOF'
import React from 'react';
export default function Dashboard() {
  return (<div style={{padding:20}}><h2>Admin Dashboard</h2><p>Placeholder</p></div>);
}
EOF

cat > ${ROOT}/admin-panel/package.json <<'EOF'
{
  "name": "grt-admin",
  "version": "0.1.0",
  "private": true,
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "@mui/material": "^5.0.0"
  },
  "scripts": {
    "start": "react-scripts start"
  }
}
EOF

# DB schema & sample seeds
cat > ${ROOT}/db/schema.sql <<'EOF'
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE,
  password_hash text,
  full_name text,
  country text,
  created_at timestamptz DEFAULT now()
);
CREATE TABLE country_info (
  country_code text PRIMARY KEY,
  name text,
  visa_summary text,
  currency text,
  laws jsonb,
  emergency_numbers jsonb,
  sim_info text,
  updated_at timestamptz DEFAULT now()
);
EOF

cat > ${ROOT}/db/seeds/country-seed.json <<'EOF'
[
  {"country_code":"IN","name":"India","visa_summary":"E-visa available","currency":"INR","laws":{},"emergency_numbers":{"police":"100"},"sim_info":"Airport SIMs"},
  {"country_code":"US","name":"United States","visa_summary":"VWP or visa","currency":"USD","laws":{},"emergency_numbers":{"police":"911"},"sim_info":"Prepaid SIMs"}
]
EOF

# scripts: generate assets
cat > ${ROOT}/scripts/generate-grt-assets.sh <<'EOF'
#!/usr/bin/env bash
# Run from inside GrtTravel/scripts directory:
# ./generate-grt-assets.sh
set -e
BASE_DIR="$(cd "$(dirname "$0")/.." && pwd)"
SRC="\${BASE_DIR}/assets/logo/source/image2.png"
OUT="\${BASE_DIR}/assets/logo"
mkdir -p "\${OUT}"
echo "Generating assets from \${SRC} -> \${OUT}"
convert "\${SRC}" -trim -background none -alpha on "\${OUT}/grt-hero-transparent.png"
convert "\${OUT}/grt-hero-transparent.png" -resize 1024x1024 -gravity center -extent 1024x1024 "\${OUT}/grt-hero-square.png"
for size in 512 384 256 192 144 96 72 48 32 16; do
  convert "\${OUT}/grt-hero-square.png" -resize "\${size}x\${size}" "\${OUT}/grt-\${size}.png"
done
convert "\${OUT}/grt-hero-transparent.png" -resize 432x432 -gravity center -extent 432x432 "\${OUT}/android-foreground.png"
convert -size 1080x1920 xc:"#0B5FFF" -gravity center -extent 1080x1920 "\${OUT}/android-background.png"
convert "\${OUT}/grt-96.png" -resize 32x32 "\${OUT}/favicon-32.png"
convert "\${OUT}/grt-96.png" -resize 16x16 "\${OUT}/favicon-16.png"
cat > "\${OUT}/monogram.svg" <<SVG
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200">
  <rect width="200" height="200" fill="#0B5FFF"/>
  <text x="100" y="124" font-family="Poppins, Arial" font-size="86" text-anchor="middle" fill="#fff" font-weight="700">GRT</text>
</svg>
SVG
echo "Done. Icons in \${OUT}"
EOF
chmod +x ${ROOT}/scripts/generate-grt-assets.sh

# Add docs and playstore checklist
cat > ${ROOT}/docs/playstore-checklist.md <<'EOF'
Play Store checklist (for your reference)
- Pre-permission screen for location (foreground only)
- Privacy policy URL
- 512x512 high-res icon
- Adaptive icons for Android
- No background location permission unless needed and justified
EOF

# GitHub Actions backend example
cat > ${ROOT}/.github/workflows/backend.yml <<'EOF'
name: Backend CI
on: [push]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Set up Node
        uses: actions/setup-node@v4
        with: {node-version: '18'}
      - name: Install backend deps
        run: |
          cd backend
          npm ci || true
EOF

# Copy placeholder source images readme
cat > ${ROOT}/assets/logo/source/README.txt <<'EOF'
Place your source images (from the chat) here and name them:
- image2.png  (primary)
- image3.png  (secondary, optional)
- image4.png  (alternate, optional)

Then run:
  cd scripts
  ./generate-grt-assets.sh
EOF

# Add bundle script (creates zip)
cat > ${ROOT}/scripts/bundle_zip.sh <<'EOF'
#!/usr/bin/env bash
set -e
ROOT="GrtTravel"
ZIP="GrtTravel.zip"
if [ -d "\${ROOT}" ]; then
  zip -r "\${ZIP}" "\${ROOT}"
  echo "Created \${ZIP}"
else
  echo "Directory \${ROOT} not found"
fi
EOF
chmod +x ${ROOT}/scripts/bundle_zip.sh

# Final: create zip
echo "Creating zip archive..."
zip -r GrtTravel.zip ${ROOT} >/dev/null
echo "Created GrtTravel.zip in current directory."
echo ""
echo "NEXT STEPS:"
echo "1) Extract GrtTravel.zip or unzip it."
echo "2) Copy your saved source images into GrtTravel/assets/logo/source/ as image2.png image3.png image4.png"
echo "3) Run: cd GrtTravel/scripts && ./generate-grt-assets.sh"
echo "4) Inspect generated assets in GrtTravel/assets/logo/ and update backend/.env.example and mobile-app/app.json"
echo "5) Push to GitHub or invite 'copilot' and I can push & continue for you."
EOF
chmod +x create_grttravel_zip_full.sh