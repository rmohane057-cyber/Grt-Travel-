// backend/routes/attachments.js
import express from 'express';
import AWS from 'aws-sdk';
import { Pool } from 'pg';
import { v4 as uuidv4 } from 'uuid';

const router = express.Router();
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// Configure AWS SDK using env variables
const s3 = new AWS.S3({
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region: process.env.AWS_REGION
});

const BUCKET = process.env.AWS_S3_BUCKET;

// POST /api/attachments/upload-url
// Body: { entity_type, entity_id, filename, mime, size_bytes, uploaded_by }
router.post('/upload-url', async (req, res) => {
  const { entity_type, entity_id, filename, mime, size_bytes, uploaded_by } = req.body;
  if (!filename || !mime) return res.status(400).send('filename and mime required');

  const key = `attachments/${Date.now()}-${uuidv4()}-${filename}`;
  const params = {
    Bucket: BUCKET,
    Key: key,
    ContentType: mime,
    ACL: 'private',
    Expires: 60 * 5 // 5 minutes
  };

  try {
    const uploadUrl = await s3.getSignedUrlPromise('putObject', params);

    // Optionally create DB record now with url placeholder; update after upload
    const client = await pool.connect();
    const url = `s3://${BUCKET}/${key}`;
    const insert = await client.query(
      `INSERT INTO attachments (entity_type, entity_id, filename, url, mime, size_bytes, uploaded_by) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id, created_at`,
      [entity_type, entity_id || null, filename, url, mime, size_bytes || null, uploaded_by || null]
    );
    client.release();

    res.json({ uploadUrl, s3Key: key, attachmentId: insert.rows[0].id });
  } catch (err) {
    console.error('S3 presign error', err);
    res.status(500).send('Server error');
  }
});

export default router;