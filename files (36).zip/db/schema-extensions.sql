-- attachments (generic)
CREATE TABLE attachments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  entity_type text NOT NULL,        -- e.g., 'business', 'user', 'place'
  entity_id uuid,                   -- reference id for the entity (nullable)
  filename text NOT NULL,
  url text NOT NULL,
  mime text,
  size_bytes bigint,
  uploaded_by uuid,                 -- user who uploaded (nullable)
  created_at timestamptz DEFAULT now()
);

-- affiliate partners and link templates
CREATE TABLE affiliate_partners (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  partner_slug text UNIQUE NOT NULL,
  base_url text NOT NULL,           -- e.g., https://affiliate.example/booking?offer={offer_id}&aff={aff_id}
  notes text,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE affiliate_links (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid REFERENCES businesses(id),
  partner_id uuid REFERENCES affiliate_partners(id),
  affiliate_template text NOT NULL,  -- e.g., https://aff.com/book?pid={place_id}&ref={user_id}
  last_updated timestamptz DEFAULT now()
);

CREATE TABLE affiliate_clicks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  affiliate_link_id uuid REFERENCES affiliate_links(id),
  user_id uuid,
  ip text,
  user_agent text,
  referer text,
  created_at timestamptz DEFAULT now()
);

-- Add affiliate fields to businesses (optional - denormalized)
ALTER TABLE businesses
  ADD COLUMN affiliate_partner_id uuid,
  ADD COLUMN affiliate_url_template text;