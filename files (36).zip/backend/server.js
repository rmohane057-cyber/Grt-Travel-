const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');

const app = express();
app.use(cors());
app.use(express.json());

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// simple health
app.get('/health', (req, res) => res.json({ ok: true }));

// Example: proxy to Google Places nearby (server keeps API key)
app.get('/api/places/nearby', async (req, res) => {
  const { lat, lng, type, radius } = req.query;
  // Validate params...
  // Use server-side request to Google Places with API key (hidden on server)
  // Then map to our business categories and return enriched data
  res.json({ results: [] });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Server running on ${PORT}`));