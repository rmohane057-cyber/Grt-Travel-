import React from 'react';
import { Card, CardContent, Typography } from '@mui/material';

export default function Dashboard() {
  return (
    <div style={{ padding: 20 }}>
      <Typography variant="h4" gutterBottom>Admin Dashboard</Typography>
      <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
        <Card style={{ width: 220 }}>
          <CardContent>
            <Typography color="textSecondary">Total Bookings</Typography>
            <Typography variant="h5">--</Typography>
          </CardContent>
        </Card>
        <Card style={{ width: 220 }}>
          <CardContent>
            <Typography color="textSecondary">Active Coupons</Typography>
            <Typography variant="h5">--</Typography>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}