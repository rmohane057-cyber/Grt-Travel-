#!/usr/bin/env bash
set -e
SRC_DIR="assets/logo/source"
OUT_DIR="assets/logo"
mkdir -p "$OUT_DIR"

# Primary image (Image 2)
SRC1="$SRC_DIR/image2.png"

# Trim and make transparent
convert "$SRC1" -trim -background none -alpha on "$OUT_DIR/grt-hero-transparent.png"

# Create square centered base
convert "$OUT_DIR/grt-hero-transparent.png" -resize 1024x1024 -gravity center -extent 1024x1024 "$OUT_DIR/grt-hero-square.png"

# Generate sizes
for size in 512 384 256 192 144 96 72 48 32 16; do
  convert "$OUT_DIR/grt-hero-square.png" -resize "${size}x${size}" "$OUT_DIR/grt-${size}.png"
done

# Adaptive icon layers
convert "$OUT_DIR/grt-hero-transparent.png" -resize 432x432 -gravity center -extent 432x432 "$OUT_DIR/android-foreground.png"
convert -size 1080x1920 xc:"#0B5FFF" -gravity center -extent 1080x1920 "$OUT_DIR/android-background.png"

# Favicon
convert "$OUT_DIR/grt-96.png" -resize 32x32 "$OUT_DIR/favicon-32.png"
convert "$OUT_DIR/grt-96.png" -resize 16x16 "$OUT_DIR/favicon-16.png"

echo "Generated assets in $OUT_DIR"