#!/usr/bin/env bash
# create_grttravel_repo_full.sh
# Creates a complete GrtTravel scaffold, copies your source logo images
# and generates icon assets (ImageMagick required). Produces GrtTravel.zip.
#
# Place your source images before running:
#  ./assets/logo/source/image2.png
#  ./assets/logo/source/image3.png
#  ./assets/logo/source/image4.png

set -e
ROOT="GrtTravel"
SRC_DIR="./assets/logo/source"
OUT_DIR="${ROOT}/assets/logo"

# Check tools
command -v convert >/dev/null 2>&1 || { echo "ImageMagick 'convert' is required. Install it and retry."; exit 1; }
command -v zip >/dev/null 2>&1 || { echo "zip is required. Install it and retry."; exit 1; }

# Clean previous
rm -rf "${ROOT}" GrtTravel.zip
mkdir -p "${ROOT}"
mkdir -p "${SRC_DIR}"
mkdir -p "${OUT_DIR}"

# Validate input images
if [ ! -f "${SRC_DIR}/image2.png" ]; then
  echo "Missing primary source: ${SRC_DIR}/image2.png"
  echo "Place your images (image2.png image3.png image4.png) and run again."
  exit 1
fi

# Create skeleton folders
mkdir -p ${ROOT}/{mobile-app,backend,admin-panel/src/pages,db,scripts,docs,.github/workflows}
mkdir -p ${ROOT}/admin-panel/public/assets/logo

# README
cat > ${ROOT}/README.md <<'EOF'
GrtTravel — scaffold bundle.
Run scripts/generate-grt-assets.sh after placing your source images in assets/logo/source/
EOF

# Minimal mobile app files (App.js, package.json, app.json)
mkdir -p ${ROOT}/mobile-app/src
cat > ${ROOT}/mobile-app/App.js <<'EOF'
import React from 'react';
import { View, Text } from 'react-native';
export default function App(){ return (<View style={{flex:1,justifyContent:'center',alignItems:'center'}}><Text>GrtTravel</Text></View>); }
EOF

cat > ${ROOT}/mobile-app/package.json <<'EOF'
{
  "name": "grttravel-mobile",
  "version": "0.1.0",
  "private": true,
  "main": "node_modules/expo/AppEntry.js",
  "scripts": { "start": "expo start" },
  "dependencies": { "expo": "~48.0.0", "react": "18.2.0", "react-native": "0.71.8" }
}
EOF

cat > ${ROOT}/mobile-app/app.json <<'EOF'
{
  "expo": {
    "name": "GrtTravel",
    "slug": "grttravel",
    "version": "1.0.0",
    "icon": "../assets/logo/grt-192.png",
    "android": {
      "package": "com.grttravel.app",
      "adaptiveIcon": {
        "foregroundImage": "../assets/logo/android-foreground.png",
        "backgroundImage": "../assets/logo/android-background.png"
      },
      "permissions": ["ACCESS_FINE_LOCATION"]
    }
  }
}
EOF

# Backend minimal files
cat > ${ROOT}/backend/server.js <<'EOF'
const express = require('express');
const app = express();
app.use(express.json());
app.get('/health', (req,res)=>res.json({ok:true}));
const PORT = process.env.PORT || 4000;
app.listen(PORT, ()=>console.log('Backend listening on', PORT));
EOF

cat > ${ROOT}/backend/package.json <<'EOF'
{ "name": "grttravel-backend", "version":"0.1.0", "main":"server.js", "scripts": {"start":"node server.js"}, "dependencies":{"express":"^4.18.2"} }
EOF

cat > ${ROOT}/backend/.env.example <<'EOF'
PORT=4000
DATABASE_URL=postgres://user:pass@host:5432/grttravel
JWT_SECRET=replace_with_strong_random
GOOGLE_MAPS_SERVER_KEY=REPLACE_ME
GOOGLE_MAPS_ANDROID_KEY=REPLACE_ME
EOF

# Admin placeholder
mkdir -p ${ROOT}/admin-panel/src/components
cat > ${ROOT}/admin-panel/src/pages/Dashboard.js <<'EOF'
import React from 'react';
export default function Dashboard(){ return (<div style={{padding:20}}><h2>Admin Dashboard</h2></div>); }
EOF

cat > ${ROOT}/admin-panel/package.json <<'EOF'
{ "name": "grt-admin", "version":"0.1.0", "private": true, "dependencies": { "react":"^18.2.0", "@mui/material":"^5.0.0" }, "scripts": {"start":"react-scripts start"} }
EOF

# DB schema and seed
cat > ${ROOT}/db/schema.sql <<'EOF'
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE TABLE users ( id uuid PRIMARY KEY DEFAULT gen_random_uuid(), email text UNIQUE, password_hash text, full_name text, country text, created_at timestamptz DEFAULT now() );
CREATE TABLE country_info ( country_code text PRIMARY KEY, name text, visa_summary text, currency text, laws jsonb, emergency_numbers jsonb, sim_info text, updated_at timestamptz DEFAULT now() );
EOF

cat > ${ROOT}/db/seeds/country-seed.json <<'EOF'
[
  {"country_code":"IN","name":"India","visa_summary":"E-visa available","currency":"INR","laws":{},"emergency_numbers":{"police":"100"},"sim_info":"Airport SIMs"},
  {"country_code":"US","name":"United States","visa_summary":"VWP or visa","currency":"USD","laws":{},"emergency_numbers":{"police":"911"},"sim_info":"Prepaid SIMs"},
  {"country_code":"GB","name":"United Kingdom","visa_summary":"Check official site","currency":"GBP","laws":{},"emergency_numbers":{"police":"999"},"sim_info":"Prepaid SIMs"},
  {"country_code":"AE","name":"United Arab Emirates","visa_summary":"Visa on arrival for many","currency":"AED","laws":{},"emergency_numbers":{"police":"999"},"sim_info":"Passport required"},
  {"country_code":"AU","name":"Australia","visa_summary":"eVisitor/eTA for some","currency":"AUD","laws":{},"emergency_numbers":{"police":"000"},"sim_info":"Prepaid SIMs"}
]
EOF

# scripts: asset generation (ImageMagick)
cat > ${ROOT}/scripts/generate-grt-assets.sh <<'EOF'
#!/usr/bin/env bash
# Run from within GrtTravel/scripts: ./generate-grt-assets.sh
set -e
BASE="$(cd "$(dirname "$0")/.." && pwd)"
SRC="\${BASE}/assets/logo/source/image2.png"
OUT="\${BASE}/assets/logo"
mkdir -p "\${OUT}"
echo "Generating assets from \${SRC}"
convert "\${SRC}" -trim -background none -alpha on "\${OUT}/grt-hero-transparent.png"
convert "\${OUT}/grt-hero-transparent.png" -resize 1024x1024 -gravity center -extent 1024x1024 "\${OUT}/grt-hero-square.png"
for s in 512 384 256 192 144 96 72 48 32 16; do
  convert "\${OUT}/grt-hero-square.png" -resize "\${s}x\${s}" "\${OUT}/grt-\${s}.png"
done
convert "\${OUT}/grt-hero-transparent.png" -resize 432x432 -gravity center -extent 432x432 "\${OUT}/android-foreground.png"
convert -size 1080x1920 xc:"#0B5FFF" -gravity center -extent 1080x1920 "\${OUT}/android-background.png"
convert "\${OUT}/grt-96.png" -resize 32x32 "\${OUT}/favicon-32.png"
convert "\${OUT}/grt-96.png" -resize 16x16 "\${OUT}/favicon-16.png"
cat > "\${OUT}/monogram.svg" <<SVG
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200">
  <rect width="200" height="200" fill="#0B5FFF"/>
  <text x="100" y="124" font-family="Poppins, Arial" font-size="86" text-anchor="middle" fill="#fff" font-weight="700">GRT</text>
</svg>
SVG
echo "Assets generated at \${OUT}"
EOF
chmod +x ${ROOT}/scripts/generate-grt-assets.sh

# Copy provided source images into scaffold
cp "${SRC_DIR}/image2.png" "${ROOT}/assets/logo/source/image2.png"
[ -f "${SRC_DIR}/image3.png" ] && cp "${SRC_DIR}/image3.png" "${ROOT}/assets/logo/source/image3.png"
[ -f "${SRC_DIR}/image4.png" ] && cp "${SRC_DIR}/image4.png" "${ROOT}/assets/logo/source/image4.png"

# Add .gitignore
cat > ${ROOT}/.gitignore <<'EOF'
node_modules/
*.env
android/keystores/
GrtTravel.zip
EOF

# Add docs placeholders
cat > ${ROOT}/docs/deploy-hostinger.md <<'EOF'
Hostinger deployment notes:
- If Hostinger supports Node.js apps: use hPanel -> Node.js app. Set env vars in hPanel.
- Recommended: use Supabase (Postgres) for DB and Hostinger only for static admin files or reverse proxy.
EOF

cat > ${ROOT}/docs/README_DEPLOY.md <<'EOF'
1) Generate assets: cd scripts && ./generate-grt-assets.sh
2) Run local dev: docker-compose (not included here) or run backend and admin locally
3) Add secrets in GitHub settings before CI or deploy
EOF

# Make bundle zip
zip -r GrtTravel.zip ${ROOT} >/dev/null
echo "GrtTravel.zip created in current directory."
echo "Open ${ROOT}/scripts/generate-grt-assets.sh and run it after editing/confirming source images if needed."
echo ""
echo "To push to your GitHub and create Release, use the push_release.sh script (see instructions)."
EOF