#!/usr/bin/env bash
set -e
ROOT="GrtTravel"
echo "Creating ${ROOT} scaffold..."

# Create skeleton structure
mkdir -p ${ROOT}/{mobile-app,backend,admin-panel/src/pages,db,assets/logo/source,scripts,docs,.github/workflows}

# IMPORTANT: place your source logos (image2.png image3.png image4.png) into assets/logo/source/ BEFORE running this script.
if [ ! -f "${ROOT}/assets/logo/source/image2.png" ]; then
  echo "Place your source logo files in ${ROOT}/assets/logo/source/ as image2.png image3.png image4.png"
  exit 1
fi

# --- Copy minimal starter files (short versions) ---
cat > ${ROOT}/README.md <<'EOF'
# GrtTravel

Bundle scaffold with mobile-app (Expo), backend (Express), admin-panel (React), DB seeds and generated logo assets.

Run scripts/generate-grt-assets.sh to create icons from assets/logo/source/image2.png image3.png image4.png
EOF

# Minimal mobile app config
cat > ${ROOT}/mobile-app/app.json <<'EOF'
{
  "expo": {
    "name": "GrtTravel",
    "slug": "grttravel",
    "version": "1.0.0",
    "icon": "../assets/logo/grt-192.png",
    "android": {
      "package": "com.grttravel.app",
      "adaptiveIcon": {
        "foregroundImage": "../assets/logo/android-foreground.png",
        "backgroundImage": "../assets/logo/android-background.png"
      },
      "permissions": ["ACCESS_FINE_LOCATION"]
    }
  }
}
EOF

# Minimal backend .env.example
cat > ${ROOT}/backend/.env.example <<'EOF'
PORT=4000
DATABASE_URL=postgres://user:pass@host:5432/grttravel
JWT_SECRET=replace_with_strong_random
GOOGLE_MAPS_SERVER_KEY=REPLACE_ME
GOOGLE_MAPS_ANDROID_KEY=REPLACE_ME
FIREBASE_SERVICE_ACCOUNT_JSON=REPLACE_ME
EOF

# Minimal Docker Compose for local
cat > ${ROOT}/docker-compose.yml <<'EOF'
version: '3.8'
services:
  db:
    image: postgres:13
    environment:
      POSTGRES_USER: grt
      POSTGRES_PASSWORD: grtpassword
      POSTGRES_DB: grttravel
    volumes:
      - db_data:/var/lib/postgresql/data
      - ./db/schema.sql:/docker-entrypoint-initdb.d/schema.sql:ro
    ports:
      - "5432:5432"
  backend:
    build:
      context: ./backend
    environment:
      DATABASE_URL: postgres://grt:grtpassword@db:5432/grttravel
      JWT_SECRET: changeme
    ports:
      - "4000:4000"
    depends_on:
      - db
volumes:
  db_data:
EOF

# Add db/schema.sql placeholder (you can replace with full schema later)
cat > ${ROOT}/db/schema.sql <<'EOF'
-- DB schema placeholder; replace or extend with full schema.sql as required.
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE,
  password_hash text,
  full_name text,
  country text,
  created_at timestamptz DEFAULT now()
);
CREATE TABLE country_info (
  country_code text PRIMARY KEY,
  name text,
  visa_summary text,
  currency text,
  laws jsonb,
  emergency_numbers jsonb,
  sim_info text,
  updated_at timestamptz DEFAULT now()
);
EOF

# scripts: generate icons with ImageMagick (assumes convert installed)
cat > ${ROOT}/scripts/generate-grt-assets.sh <<'EOF'
#!/usr/bin/env bash
set -e
SRC_DIR="../assets/logo/source"
OUT_DIR="../assets/logo"
mkdir -p "${OUT_DIR}"
# Using image2.png as primary (Primary=2)
SRC1="${SRC_DIR}/image2.png"
# Trim and create transparent PNG
convert "$SRC1" -trim -background none -alpha on "$OUT_DIR/grt-hero-transparent.png"
# Center and square
convert "$OUT_DIR/grt-hero-transparent.png" -resize 1024x1024 -gravity center -extent 1024x1024 "$OUT_DIR/grt-hero-square.png"
for size in 512 384 256 192 144 96 72 48 32 16; do
  convert "$OUT_DIR/grt-hero-square.png" -resize "\${size}x\${size}" "$OUT_DIR/grt-\${size}.png"
done
# Android adaptive
convert "$OUT_DIR/grt-hero-transparent.png" -resize 432x432 -gravity center -extent 432x432 "$OUT_DIR/android-foreground.png"
convert -size 1080x1920 xc:"#0B5FFF" -gravity center -extent 1080x1920 "$OUT_DIR/android-background.png"
# Favicon
convert "$OUT_DIR/grt-96.png" -resize 32x32 "$OUT_DIR/favicon-32.png"
convert "$OUT_DIR/grt-96.png" -resize 16x16 "$OUT_DIR/favicon-16.png"
# Generate simple monogram SVG (text-based)
cat > "$OUT_DIR/monogram.svg" <<SVG
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200">
  <rect width="200" height="200" fill="#0B5FFF"/>
  <text x="100" y="120" font-family="Poppins, Arial, sans-serif" font-size="90" text-anchor="middle" fill="#ffffff" font-weight="700">GRT</text>
</svg>
SVG
echo "Assets generated in assets/logo/"
EOF
chmod +x ${ROOT}/scripts/generate-grt-assets.sh

# Create placeholder admin public/favicon reference
cat > ${ROOT}/admin-panel/public_index_placeholder.txt <<'EOF'
Place generated favicon files into admin-panel/public/assets/logo/
and update public/index.html to reference favicon-32.png
EOF

# Create a short bundle command
cat > ${ROOT}/scripts/bundle_zip.sh <<'EOF'
#!/usr/bin/env bash
set -e
ROOT="GrtTravel"
ZIPNAME="\${ROOT}.zip"
if [ -d "\${ROOT}" ]; then
  zip -r "\${ZIPNAME}" "\${ROOT}"
  echo "Created \${ZIPNAME}"
else
  echo "\${ROOT} not found. Run create_grttravel_zip.sh first."
fi
EOF
chmod +x ${ROOT}/scripts/bundle_zip.sh

# Create a minimal placeholder for logo sources so user knows what to add
cat > ${ROOT}/assets/logo/source/README.txt <<'EOF'
Place your source images here as:
 - image2.png  (primary)
 - image3.png  (secondary)
 - image4.png  (alternate)
Then run:
  cd scripts
  ./generate-grt-assets.sh
EOF

# Create final zip
zip -r GrtTravel.zip ${ROOT} >/dev/null
echo "Created GrtTravel.zip in current directory. Unzip and inspect ${ROOT}/"
echo "Next steps:"
echo "  - Place your source images into ${ROOT}/assets/logo/source/"
echo "  - Run ${ROOT}/scripts/generate-grt-assets.sh to produce icons"
echo "  - Edit backend/.env.example, mobile-app/app.json and other configs as needed"
echo "  - Push to GitHub or invite copilot for me to push directly"