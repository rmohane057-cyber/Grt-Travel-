-- Basic schema (truncated)
CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE,
  password_hash text,
  full_name text,
  country text,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE businesses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  place_id text UNIQUE,
  name text,
  category text,
  address text,
  lat double precision,
  lng double precision,
  approved boolean DEFAULT false,
  featured boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id),
  business_id uuid REFERENCES businesses(id),
  provider_reference text, -- affiliate provider booking id
  status text,
  amount numeric(10,2),
  created_at timestamptz DEFAULT now()
);

CREATE TABLE country_info (
  country_code text PRIMARY KEY,
  name text,
  visa_summary text,
  currency text,
  laws jsonb,
  emergency_numbers jsonb,
  sim_info text
);