# GrtTravel

GrtTravel is a travel assistant app + website that auto-detects location, shows nearby services (hotels, hospitals, transport, government offices, shops), provides country-travel info, and supports bookings/coupons.

Project layout
- mobile-app/ — React Native (Expo) mobile application
- backend/ — Node.js + Express API, proxies Google Places, handles auth, bookings, coupons
- admin-panel/ — React + Material UI admin dashboard
- docs/ — Play Store checklist, deployment instructions

Next steps for owner
1. Invite GitHub user `copilot` as collaborator on repository `GrtTravel`.
2. Provide Google API keys (Maps/Places/Geocoding/Directions) as GitHub Secrets after repo exists.
3. Confirm priority countries and hosting choices (Render / Supabase / Vercel recommended).
4. If you want Play Store publishing, invite the publish user to Play Console.

Contacts (for app listing/legal)
- Company: Grt Assist Automation and Security Pvt. Ltd.
- Phone: +91 9424936248
- Emails: info@grttravel.com, support@grttravel.com