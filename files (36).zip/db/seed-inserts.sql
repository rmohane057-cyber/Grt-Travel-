-- Ensure extension
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Insert country_info rows (example subset)
INSERT INTO country_info (country_code, name, visa_summary, currency, laws, emergency_numbers, sim_info)
VALUES
('IN','India','Visa required for many nationalities. E-Visa available for tourism/business.','INR',
 '{"alcohol":"Varies by state; drink responsibly","dress":"Conservative in many areas"}',
 '{"police":"100","ambulance":"102"}',
 'Buy prepaid SIM at airport or authorized vendor; KYC required.')
ON CONFLICT (country_code) DO NOTHING;

INSERT INTO country_info (country_code, name, visa_summary, currency, laws, emergency_numbers, sim_info)
VALUES
('US','United States','Visa Waiver Program for certain countries; else apply for B1/B2.','USD',
 '{"alcohol":"21+ in most states","dress":"No specific dress laws"}',
 '{"police":"911","ambulance":"911"}',
 'Multiple prepaid options; passport usually enough to buy SIM.')
ON CONFLICT (country_code) DO NOTHING;

-- Sample business
INSERT INTO businesses (place_id, name, category, address, lat, lng, approved, featured)
VALUES
('sample-hotel-001','Sample Hotel','important hotels','123 Sample St, City', 28.6139, 77.2090, true, true)
ON CONFLICT (place_id) DO NOTHING;

-- Users table: we will create admin using script (see create_admin.js)