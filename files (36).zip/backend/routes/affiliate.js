// backend/routes/affiliate.js
import express from 'express';
import { Pool } from 'pg';
const router = express.Router();
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// Helper: render template variables
function renderTemplate(tpl, vars) {
  return tpl.replace(/\{([a-zA-Z0-9_]+)\}/g, (_, k) => (vars[k] !== undefined ? encodeURIComponent(String(vars[k])) : ''));
}

// GET /affiliate/redirect?link_id=<uuid>&user_id=<uuid>
router.get('/redirect', async (req, res) => {
  const { link_id, user_id } = req.query;
  if (!link_id) return res.status(400).send('link_id required');

  const client = await pool.connect();
  try {
    const linkRes = await client.query('SELECT id, affiliate_template FROM affiliate_links WHERE id = $1', [link_id]);
    if (linkRes.rowCount === 0) return res.status(404).send('Affiliate link not found');

    const link = linkRes.rows[0];
    const businessVars = {}; // optionally fetch business info if needed
    const vars = { user_id: user_id || '', ...businessVars };
    const targetUrl = renderTemplate(link.affiliate_template, vars);

    // Log the click
    await client.query(
      `INSERT INTO affiliate_clicks (affiliate_link_id, user_id, ip, user_agent, referer) VALUES ($1,$2,$3,$4,$5)`,
      [link_id, user_id || null, req.ip, req.get('User-Agent') || null, req.get('Referer') || null]
    );

    // Redirect
    res.redirect(targetUrl);
  } catch (err) {
    console.error('Affiliate redirect error', err);
    res.status(500).send('Server error');
  } finally {
    client.release();
  }
});

export default router;