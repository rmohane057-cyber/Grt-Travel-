#!/usr/bin/env bash
set -e

ROOT_DIR="GrtTravel"
echo "Creating project skeleton in ./${ROOT_DIR}"

# Create directories
mkdir -p ${ROOT_DIR}/{mobile-app,backend,admin-panel/src/pages,db,.github/workflows,docs}
cd ${ROOT_DIR}

# Top-level README
cat > README.md <<'EOF'
# GrtTravel

GrtTravel — Travel assistant app + admin + backend.

Structure
- mobile-app/ — Expo React Native (maps, location, nearby)
- backend/ — Node.js + Express API (Google Places proxy, geocode, auth stubs)
- admin-panel/ — React + Material UI admin dashboard
- db/ — schema and seed data (country_info)
- docs/ — deployment and Play Store checklist

How to run locally
1. Backend
   - cd backend
   - cp .env.example .env and set env values
   - npm install
   - psql -f ../db/schema.sql (or run migrations)
   - npm start

2. Admin
   - cd admin-panel
   - npm install
   - npm start

3. Mobile (Expo)
   - cd mobile-app
   - npm install
   - expo start

Build APK (recommended: EAS)
- Install EAS CLI: npm i -g eas-cli
- In mobile-app: eas build:configure
- Build AAB: eas build -p android --profile production
- Download resulting AAB and upload to Play Console (or distribute directly)

Secrets (add these to your environment / GitHub Secrets)
- DATABASE_URL
- JWT_SECRET
- GOOGLE_MAPS_SERVER_KEY
- GOOGLE_MAPS_ANDROID_KEY
- FIREBASE_SERVICE_ACCOUNT_JSON
- STRIPE_SECRET (optional)
- ANDROID_KEYSTORE / EAS credentials (if using CI)
EOF

# -------- mobile-app files --------
mkdir -p mobile-app
cat > mobile-app/App.js <<'EOF'
import React, { useEffect, useState } from 'react';
import { View, Text, Button } from 'react-native';
import * as Location from 'expo-location';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function App() {
  const [statusMsg, setStatusMsg] = useState('Preparing...');
  const [coords, setCoords] = useState(null);

  useEffect(() => {
    (async () => {
      const cached = await AsyncStorage.getItem('cached_location');
      if (cached) {
        const c = JSON.parse(cached);
        setCoords(c);
        setStatusMsg(`Using cached location: ${c.lat}, ${c.lng}`);
        return;
      }

      // In production show a pre-permission explanation screen before calling this
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setStatusMsg('Location permission denied. Please select city manually.');
        return;
      }

      const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      const payload = { lat: loc.coords.latitude, lng: loc.coords.longitude, ts: Date.now() };
      setCoords(payload);
      setStatusMsg('Location detected.');
      await AsyncStorage.setItem('cached_location', JSON.stringify(payload));
      // Call backend to reverse geocode and fetch country info:
      // fetch(`${process.env.BACKEND_URL}/api/geocode/reverse?lat=${payload.lat}&lng=${payload.lng}`)
    })();
  }, []);

  return (
    <View style={{flex:1,justifyContent:'center',alignItems:'center',padding:20}}>
      <Text style={{marginBottom:10}}>{statusMsg}</Text>
      {coords && <Text>{`Lat: ${coords.lat}  Lng: ${coords.lng}`}</Text>}
      <Button title="Manual city selection" onPress={() => {/* navigate to ManualCityScreen */}} />
    </View>
  );
}
EOF

cat > mobile-app/package.json <<'EOF'
{
  "name": "grttravel-mobile",
  "version": "0.1.0",
  "private": true,
  "main": "node_modules/expo/AppEntry.js",
  "scripts": {
    "start": "expo start",
    "android": "expo run:android",
    "ios": "expo run:ios",
    "web": "expo start --web"
  },
  "dependencies": {
    "expo": "~48.0.0",
    "expo-location": "~15.0.1",
    "react": "18.2.0",
    "react-native": "0.71.8",
    "@react-native-async-storage/async-storage": "^1.17.11"
  }
}
EOF

cat > mobile-app/app.json <<'EOF'
{
  "expo": {
    "name": "GrtTravel",
    "slug": "grttravel",
    "version": "1.0.0",
    "android": {
      "package": "com.grttravel.app",
      "permissions": ["ACCESS_FINE_LOCATION"],
      "config": {
        "googleMaps": {
          "apiKey": "GOOGLE_MAPS_ANDROID_KEY_PLACEHOLDER"
        }
      }
    },
    "extra": {
      "backendUrl": "https://your-backend.example.com"
    }
  }
}
EOF

# -------- backend files --------
mkdir -p backend
cat > backend/server.js <<'EOF'
const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch');
const { Pool } = require('pg');
require('express-async-errors');

const app = express();
app.use(cors());
app.use(express.json());

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// Health
app.get('/health', (req, res) => res.json({ ok: true }));

// Reverse geocode
app.get('/api/geocode/reverse', async (req, res) => {
  const { lat, lng } = req.query;
  if (!lat || !lng) return res.status(400).json({ error: 'lat & lng required' });
  const key = process.env.GOOGLE_MAPS_SERVER_KEY;
  const url = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&key=${key}`;
  const r = await fetch(url);
  const json = await r.json();
  const components = json.results?.[0]?.address_components || [];
  const find = type => (components.find(c => c.types.includes(type)) || {}).long_name || '';
  const country = find('country');
  const state = find('administrative_area_level_1');
  const city = find('locality') || find('administrative_area_level_2');
  const postal = find('postal_code');
  res.json({ country, state, city, postal, raw: json });
});

// Places nearby (proxy)
app.get('/api/places/nearby', async (req, res) => {
  const { lat, lng, radius = 5000, keyword } = req.query;
  if (!lat || !lng) return res.status(400).json({ error: 'lat,lng required' });
  const key = process.env.GOOGLE_MAPS_SERVER_KEY;
  const params = new URLSearchParams({ location: `${lat},${lng}`, radius: `${radius}`, key });
  if (keyword) params.set('keyword', keyword);
  const url = `https://maps.googleapis.com/maps/api/place/nearbysearch/json?${params.toString()}`;
  const r = await fetch(url);
  const json = await r.json();
  const results = (json.results || []).map(p => ({
    id: p.place_id,
    name: p.name,
    address: p.vicinity || p.formatted_address,
    location: p.geometry?.location,
    opening_hours: p.opening_hours || null,
    rating: p.rating || null,
    types: p.types || []
  }));
  res.json({ results, next_page_token: json.next_page_token || null });
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: err.message || 'Server error' });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Server running on ${PORT}`));
EOF

cat > backend/package.json <<'EOF'
{
  "name": "grttravel-backend",
  "version": "0.1.0",
  "main": "server.js",
  "scripts": {
    "start": "node server.js",
    "dev": "nodemon server.js"
  },
  "dependencies": {
    "cors": "^2.8.5",
    "express": "^4.18.2",
    "node-fetch": "^2.6.7",
    "pg": "^8.11.0",
    "express-async-errors": "^3.1.1"
  }
}
EOF

cat > backend/.env.example <<'EOF'
PORT=4000
DATABASE_URL=postgres://user:pass@host:5432/grttravel
JWT_SECRET=replace_with_strong_random
GOOGLE_MAPS_SERVER_KEY=REPLACE_ME
GOOGLE_MAPS_ANDROID_KEY=REPLACE_ME
FIREBASE_SERVICE_ACCOUNT_JSON=REPLACE_ME
STRIPE_SECRET=REPLACE_ME
EOF

# -------- admin-panel files --------
mkdir -p admin-panel/src/pages
cat > admin-panel/src/pages/Dashboard.js <<'EOF'
import React from 'react';
import { Card, CardContent, Typography } from '@mui/material';

export default function Dashboard() {
  return (
    <div style={{ padding: 20 }}>
      <Typography variant="h4" gutterBottom>Admin Dashboard</Typography>
      <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
        <Card style={{ width: 220 }}>
          <CardContent>
            <Typography color="textSecondary">Total Bookings</Typography>
            <Typography variant="h5">--</Typography>
          </CardContent>
        </Card>
        <Card style={{ width: 220 }}>
          <CardContent>
            <Typography color="textSecondary">Active Coupons</Typography>
            <Typography variant="h5">--</Typography>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
EOF

cat > admin-panel/package.json <<'EOF'
{
  "name": "grt-admin",
  "version": "0.1.0",
  "private": true,
  "dependencies": {
    "@mui/material": "^5.0.0",
    "axios": "^1.0.0",
    "react": "^18.0.0",
    "react-dom": "^18.0.0",
    "react-router-dom": "^6.0.0"
  },
  "scripts": {
    "start": "react-scripts start",
    "build": "react-scripts build"
  }
}
EOF

# -------- db files --------
cat > db/schema.sql <<'EOF'
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE,
  password_hash text,
  full_name text,
  country text,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE businesses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  place_id text UNIQUE,
  name text,
  category text,
  address text,
  lat double precision,
  lng double precision,
  approved boolean DEFAULT false,
  featured boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id),
  business_id uuid REFERENCES businesses(id),
  provider_reference text,
  status text,
  amount numeric(10,2),
  created_at timestamptz DEFAULT now()
);

CREATE TABLE country_info (
  country_code text PRIMARY KEY,
  name text,
  visa_summary text,
  currency text,
  laws jsonb,
  emergency_numbers jsonb,
  sim_info text,
  updated_at timestamptz DEFAULT now()
);
EOF

cat > db/seeds/country-seed.json <<'EOF'
[
  {
    "country_code": "IN",
    "name": "India",
    "visa_summary": "Visa required for many nationalities. E-Visa available for tourism/business.",
    "currency": "INR",
    "laws": { "alcohol": "Varies by state", "dress": "Conservative in many areas" },
    "emergency_numbers": { "police": "100", "ambulance": "102" },
    "sim_info": "Buy prepaid SIM at airport or authorized vendor; KYC required."
  },
  {
    "country_code": "US",
    "name": "United States",
    "visa_summary": "Visa Waiver Program for certain countries; else apply for B1/B2.",
    "currency": "USD",
    "laws": { "alcohol": "21+ in most states", "dress": "No specific dress laws" },
    "emergency_numbers": { "police": "911", "ambulance": "911" },
    "sim_info": "Multiple prepaid options; passport usually enough to buy SIM at store."
  },
  {
    "country_code": "GB",
    "name": "United Kingdom",
    "visa_summary": "Visa requirements vary by nationality; check official site.",
    "currency": "GBP",
    "laws": { "alcohol": "18+ in most places", "dress": "No specific dress laws" },
    "emergency_numbers": { "police": "999", "ambulance": "999" },
    "sim_info": "Prepaid SIM widely available at airports and shops."
  },
  {
    "country_code": "AE",
    "name": "United Arab Emirates",
    "visa_summary": "Visa on arrival for many nationalities; check rules.",
    "currency": "AED",
    "laws": { "alcohol": "Restricted; follow local laws", "dress": "Conservative in public areas" },
    "emergency_numbers": { "police": "999", "ambulance": "998" },
    "sim_info": "SIMs available at airport kiosks and telco stores; passport required."
  },
  {
    "country_code": "AU",
    "name": "Australia",
    "visa_summary": "eVisitor and eTA available for some nationalities; others need visas.",
    "currency": "AUD",
    "laws": { "alcohol": "18+ in most states", "dress": "No strict dress codes" },
    "emergency_numbers": { "police": "000", "ambulance": "000" },
    "sim_info": "Prepaid SIMs available at airports and shops; ID may be needed."
  }
]
EOF

# -------- CI workflow example --------
mkdir -p .github/workflows
cat > .github/workflows/backend.yml <<'EOF'
name: Backend CI

on:
  push:
    branches: [ main, feature/* ]
  pull_request:
    branches: [ main ]

jobs:
  build-and-test:
    runs-on: ubuntu-latest
    services:
      postgres:
        image: postgres:13
        env:
          POSTGRES_DB: grttravel
          POSTGRES_USER: postgres
          POSTGRES_PASSWORD: postgres
        ports:
          - 5432:5432
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
    steps:
      - uses: actions/checkout@v4
      - name: Set up Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '18'
      - name: Install dependencies
        run: |
          cd backend
          npm ci
      - name: Run backend tests
        run: |
          cd backend
          npm test
EOF

# -------- docs --------
cat > docs/playstore-checklist.md <<'EOF'
# Play Store Checklist (GrtTravel)

- Pre-permission explanation screen for location (foreground-only).
- Privacy Policy URL and Terms & Conditions hosted on HTTPS domain.
- Limit permissions to required scopes only.
- AndroidManifest: no background location permission.
- Use restricted API keys: server key only on backend; Android key restricted by package name + SHA-1.
- Provide clear contact info in Play Console listing.
- Prepare screenshots, icons, and feature graphic.
EOF

echo "Scaffold created in ./${ROOT_DIR}"
echo "Run the following to create a zip:"
echo "  cd ${ROOT_DIR} && zip -r ../${ROOT_DIR}.zip ."
echo ""
echo "Next steps:"
echo "  - Add your API keys and secrets (see README.md)"
echo "  - Inspect and extend files (implement auth, DB migrations, admin UI, mobile screens)"
echo "  - Push to GitHub, add GitHub Secrets, and deploy to your chosen hosts"