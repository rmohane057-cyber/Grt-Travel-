#!/usr/bin/env bash
set -e
SRC="assets/logo/source/logo-original.png"
OUTDIR="assets/logo"
mkdir -p "$OUTDIR"

# Make a transparent PNG (trim whitespace and add alpha)
convert "$SRC" -trim -background none -alpha remove -alpha on "$OUTDIR/logo-transparent.png"

# Square-crop and create multiple sizes
for size in 512 192 144 96 72 48 32 16; do
  convert "$OUTDIR/logo-transparent.png" -resize "${size}x${size}" -background none -gravity center -extent "${size}x${size}" "$OUTDIR/logo-${size}.png"
done

# Android adaptive icon layers (foreground should be transparent PNG, background can be solid color)
convert "$OUTDIR/logo-transparent.png" -resize 432x432 -background none -gravity center -extent 432x432 "$OUTDIR/android-foreground.png"
convert -size 1080x1920 xc:"#0B3D91" -gravity center -extent 1080x1920 "$OUTDIR/android-background.png"

# Create favicon (32x32 & 16x16) from 96 px
convert "$OUTDIR/logo-96.png" -resize 32x32 "$OUTDIR/favicon-32.png"
convert "$OUTDIR/logo-96.png" -resize 16x16 "$OUTDIR/favicon-16.png"

echo "Icons generated in $OUTDIR"