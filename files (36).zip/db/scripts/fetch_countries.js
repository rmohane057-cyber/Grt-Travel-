/**
 * fetch_countries.js
 * - Fetches all countries from restcountries.com
 * - Produces:
 *    -> db/country-full.json
 *    -> db/country-full.csv
 *    -> db/country-full-seed.sql   (INSERT ... ON CONFLICT DO UPDATE)
 *
 * Usage:
 *   node fetch_countries.js
 *
 * Requires: node >= 18 or install node-fetch for older Node.
 */
import fs from 'fs';
import https from 'https';

const API = 'https://restcountries.com/v3.1/all';

function fetchJson(url) {
  return new Promise((resolve, reject) => {
    https.get(url, res => {
      let data = '';
      res.on('data', chunk => (data += chunk));
      res.on('end', () => resolve(JSON.parse(data)));
    }).on('error', reject);
  });
}

function safe(s){ return (s===undefined || s===null) ? '' : String(s).replace(/'/g,"''"); }

(async () => {
  console.log('Fetching countries from', API);
  const countries = await fetchJson(API);

  // Map to simplified objects
  const rows = countries.map(c => {
    const cca2 = c.cca2 || '';
    const cca3 = c.cca3 || '';
    const name = c.name?.common || '';
    const capital = Array.isArray(c.capital) && c.capital.length ? c.capital[0] : '';
    const latlng = Array.isArray(c.latlng) && c.latlng.length >= 2 ? { lat: c.latlng[0], lng: c.latlng[1] } : { lat: null, lng: null };
    const currencies = c.currencies ? Object.keys(c.currencies).join(',') : '';
    const callingCodes = c.idd?.root ? ((c.idd.root || '') + (Array.isArray(c.idd.suffixes) ? c.idd.suffixes[0] : '')) : '';
    const timezones = Array.isArray(c.timezones) ? c.timezones.join('|') : '';
    const languages = c.languages ? Object.values(c.languages).join(',') : '';
    const region = c.region || '';
    const subregion = c.subregion || '';
    return {
      country_code: cca2,
      country_code3: cca3,
      name,
      capital,
      lat: latlng.lat,
      lng: latlng.lng,
      currencies,
      calling_codes: callingCodes,
      timezones,
      languages,
      region,
      subregion,
      visa_summary: '',
      sim_info: '',
      emergency_numbers: JSON.stringify({ police: '', ambulance: '', fire: '' })
    };
  });

  // Write JSON
  fs.writeFileSync('db/country-full.json', JSON.stringify(rows, null, 2));
  console.log('Wrote db/country-full.json');

  // Write CSV
  const csvHeader = [
    'country_code','country_code3','name','capital','lat','lng','currencies','calling_codes','timezones','languages','region','subregion','visa_summary','sim_info','emergency_numbers'
  ].join(',');
  const csvLines = rows.map(r => {
    return [
      `"${r.country_code}"`,
      `"${r.country_code3}"`,
      `"${safe(r.name)}"`,
      `"${safe(r.capital)}"`,
      `${r.lat === null ? '' : r.lat}`,
      `${r.lng === null ? '' : r.lng}`,
      `"${safe(r.currencies)}"`,
      `"${safe(r.calling_codes)}"`,
      `"${safe(r.timezones)}"`,
      `"${safe(r.languages)}"`,
      `"${safe(r.region)}"`,
      `"${safe(r.subregion)}"`,
      `"${safe(r.visa_summary)}"`,
      `"${safe(r.sim_info)}"`,
      `"${safe(r.emergency_numbers)}"`
    ].join(',');
  });
  fs.writeFileSync('db/country-full.csv', csvHeader + '\n' + csvLines.join('\n'));
  console.log('Wrote db/country-full.csv');

  // Write SQL seed (upsert)
  const sqlLines = rows.map(r => {
    const vals = [
      `'${safe(r.country_code)}'`,
      `'${safe(r.name)}'`,
      `'${safe(r.visa_summary)}'`,
      `'${safe(r.currencies)}'`,
      `$$${r.emergency_numbers}$$`,
      `'${safe(r.sim_info)}'`,
      `${r.lat === null ? 'NULL' : r.lat}`,
      `${r.lng === null ? 'NULL' : r.lng}`
    ];
    // The country_info table in our schema: country_code, name, visa_summary, currency, laws, emergency_numbers, sim_info, updated_at
    return `INSERT INTO country_info (country_code, name, visa_summary, currency, laws, emergency_numbers, sim_info, updated_at)
VALUES (${vals.join(',')}, now())
ON CONFLICT (country_code) DO UPDATE SET name = EXCLUDED.name, visa_summary = EXCLUDED.visa_summary, currency = EXCLUDED.currency, emergency_numbers = EXCLUDED.emergency_numbers, sim_info = EXCLUDED.sim_info, updated_at = now();`;
  });
  fs.writeFileSync('db/country-full-seed.sql', sqlLines.join('\n\n'));
  console.log('Wrote db/country-full-seed.sql');

  console.log('Done. Files written to db/*.');
})();