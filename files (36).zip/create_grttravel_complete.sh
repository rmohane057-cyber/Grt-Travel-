#!/usr/bin/env bash
# create_grttravel_complete.sh
# Creates a full GrtTravel scaffold, copies provided logo images,
# generates helper scripts (asset generation, country fetch), and bundles GrtTravel.zip.
# Optionally pushes to GitHub and creates a Release (requires gh CLI and git).
#
# Usage:
# 1) Place your source logos at ./assets/logo/source/image2.png image3.png image4.png
# 2) ./create_grttravel_complete.sh
# 3) (optional) ./scripts/push_release.sh <owner/repo> v1.0 "GrtTravel v1.0" "Initial scaffold + assets"
#
set -e
ROOT="GrtTravel"
SRC_DIR="./assets/logo/source"
OUT_DIR="${ROOT}/assets/logo"

# Prereqs check
cmds=("convert" "zip" "git" "gh" "node")
for c in "${cmds[@]}"; do
  if ! command -v $c >/dev/null 2>&1; then
    echo "Warning: command '$c' not found. Some steps may fail. Install it if needed."
  fi
done

# Clean previous
rm -rf "${ROOT}" GrtTravel.zip
mkdir -p "${ROOT}"
mkdir -p "${SRC_DIR}"
mkdir -p "${OUT_DIR}"

# Ensure logos exist
if [ ! -f "${SRC_DIR}/image2.png" ]; then
  echo "Please place your source images in ${SRC_DIR} named: image2.png image3.png image4.png"
  echo "Aborting."
  exit 1
fi

# Create repository structure and files
mkdir -p ${ROOT}/{mobile-app,backend,admin-panel/src/pages,db/scripts,scripts,docs,.github/workflows}
mkdir -p ${ROOT}/admin-panel/public/assets/logo
mkdir -p ${ROOT}/assets/logo/source

# Copy provided source images into scaffold so the generated zip includes them
cp "${SRC_DIR}/image2.png" "${ROOT}/assets/logo/source/image2.png"
[ -f "${SRC_DIR}/image3.png" ] && cp "${SRC_DIR}/image3.png" "${ROOT}/assets/logo/source/image3.png"
[ -f "${SRC_DIR}/image4.png" ] && cp "${SRC_DIR}/image4.png" "${ROOT}/assets/logo/source/image4.png"

# README
cat > ${ROOT}/README.md <<'EOF'
GrtTravel — full scaffold (mobile, backend, admin, DB seeds, assets, scripts).

Run scripts/generate-grt-assets.sh after placing source images in assets/logo/source/.
Seed DB: psql "<DATABASE_URL>" -f db/schema.sql
Generate countries: node db/scripts/fetch_countries.js
EOF

# .gitignore
cat > ${ROOT}/.gitignore <<'EOF'
node_modules/
*.env
*.keystore
GrtTravel.zip
EOF

# Docker Compose (minimal)
cat > ${ROOT}/docker-compose.yml <<'EOF'
version: '3.8'
services:
  db:
    image: postgres:13
    environment:
      POSTGRES_USER: grt
      POSTGRES_PASSWORD: grtpassword
      POSTGRES_DB: grttravel
    volumes:
      - db_data:/var/lib/postgresql/data
      - ./db/schema.sql:/docker-entrypoint-initdb.d/schema.sql:ro
    ports:
      - "5432:5432"
  backend:
    build:
      context: ./backend
    environment:
      DATABASE_URL: postgres://grt:grtpassword@db:5432/grttravel
      JWT_SECRET: changeme
    ports:
      - "4000:4000"
    depends_on:
      - db
volumes:
  db_data:
EOF

# Mobile app: App.js, package.json, app.json
mkdir -p ${ROOT}/mobile-app/src
cat > ${ROOT}/mobile-app/App.js <<'EOF'
import React from 'react';
import { View, Text } from 'react-native';
export default function App(){ return (<View style={{flex:1,justifyContent:'center',alignItems:'center'}}><Text>GrtTravel</Text></View>); }
EOF

cat > ${ROOT}/mobile-app/package.json <<'EOF'
{
  "name": "grttravel-mobile",
  "version": "0.1.0",
  "private": true,
  "scripts": { "start": "expo start" },
  "dependencies": {
    "expo": "~48.0.0",
    "react": "18.2.0",
    "react-native": "0.71.8",
    "expo-location": "^15.0.0",
    "@react-native-async-storage/async-storage": "^1.17.0"
  }
}
EOF

cat > ${ROOT}/mobile-app/app.json <<'EOF'
{
  "expo": {
    "name": "GrtTravel",
    "slug": "grttravel",
    "version": "1.0.0",
    "icon": "../assets/logo/grt-192.png",
    "android": {
      "package": "com.grttravel.app",
      "adaptiveIcon": {
        "foregroundImage": "../assets/logo/android-foreground.png",
        "backgroundImage": "../assets/logo/android-background.png"
      },
      "permissions": ["ACCESS_FINE_LOCATION"]
    }
  }
}
EOF

# Backend: server, package.json, Dockerfile, env example
cat > ${ROOT}/backend/server.js <<'EOF'
import express from 'express';
import cors from 'cors';
import affiliateRoutes from './routes/affiliate.js';
import attachmentsRoutes from './routes/attachments.js';
const app = express();
app.use(cors());
app.use(express.json());
app.get('/health', (req,res) => res.json({ok:true}));
app.use('/api/affiliate', affiliateRoutes);
app.use('/api/attachments', attachmentsRoutes);
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log('Backend listening on', PORT));
EOF

cat > ${ROOT}/backend/package.json <<'EOF'
{
  "name": "grttravel-backend",
  "version": "0.1.0",
  "type": "module",
  "main": "server.js",
  "scripts": { "start": "node server.js" },
  "dependencies": {
    "express": "^4.18.2",
    "cors": "^2.8.5",
    "pg": "^8.11.0",
    "aws-sdk": "^2.1360.0",
    "uuid": "^9.0.0"
  }
}
EOF

cat > ${ROOT}/backend/Dockerfile <<'EOF'
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --production
COPY . .
EXPOSE 4000
CMD ["node", "server.js"]
EOF

cat > ${ROOT}/backend/.env.example <<'EOF'
PORT=4000
DATABASE_URL=postgres://user:pass@host:5432/grttravel
JWT_SECRET=replace_with_strong_random
GOOGLE_MAPS_SERVER_KEY=REPLACE_ME
GOOGLE_MAPS_ANDROID_KEY=REPLACE_ME
AWS_ACCESS_KEY_ID=REPLACE_ME
AWS_SECRET_ACCESS_KEY=REPLACE_ME
AWS_REGION=REPLACE_ME
AWS_S3_BUCKET=REPLACE_ME
EOF

# Backend: routes/affiliate.js
mkdir -p ${ROOT}/backend/routes
cat > ${ROOT}/backend/routes/affiliate.js <<'EOF'
import express from 'express';
import { Pool } from 'pg';
const router = express.Router();
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

function renderTemplate(tpl, vars) {
  return tpl.replace(/\\{([a-zA-Z0-9_]+)\\}/g, (_, k) => (vars[k] !== undefined ? encodeURIComponent(String(vars[k])) : ''));
}

router.get('/redirect', async (req, res) => {
  const { link_id, user_id } = req.query;
  if (!link_id) return res.status(400).send('link_id required');
  const client = await pool.connect();
  try {
    const linkRes = await client.query('SELECT id, affiliate_template FROM affiliate_links WHERE id = $1', [link_id]);
    if (linkRes.rowCount === 0) return res.status(404).send('Affiliate link not found');
    const link = linkRes.rows[0];
    const vars = { user_id: user_id || '' };
    const targetUrl = renderTemplate(link.affiliate_template, vars);
    await client.query('INSERT INTO affiliate_clicks (affiliate_link_id, user_id, ip, user_agent, referer) VALUES ($1,$2,$3,$4,$5)', [link_id, user_id || null, req.ip, req.get('User-Agent') || null, req.get('Referer') || null]);
    res.redirect(targetUrl);
  } catch (err) {
    console.error('Affiliate redirect error', err);
    res.status(500).send('Server error');
  } finally {
    client.release();
  }
});

export default router;
EOF

# Backend: routes/attachments.js
cat > ${ROOT}/backend/routes/attachments.js <<'EOF'
import express from 'express';
import AWS from 'aws-sdk';
import { Pool } from 'pg';
import { v4 as uuidv4 } from 'uuid';
const router = express.Router();
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const s3 = new AWS.S3({
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region: process.env.AWS_REGION
});
const BUCKET = process.env.AWS_S3_BUCKET;

router.post('/upload-url', async (req, res) => {
  const { entity_type, entity_id, filename, mime, size_bytes, uploaded_by } = req.body;
  if (!filename || !mime) return res.status(400).send('filename and mime required');
  const key = `attachments/${Date.now()}-${uuidv4()}-${filename}`;
  const params = { Bucket: BUCKET, Key: key, ContentType: mime, ACL: 'private', Expires: 60 * 5 };
  try {
    const uploadUrl = await s3.getSignedUrlPromise('putObject', params);
    const client = await pool.connect();
    const url = `s3://${BUCKET}/${key}`;
    const insert = await client.query('INSERT INTO attachments (entity_type, entity_id, filename, url, mime, size_bytes, uploaded_by) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id', [entity_type, entity_id || null, filename, url, mime, size_bytes || null, uploaded_by || null]);
    client.release();
    res.json({ uploadUrl, s3Key: key, attachmentId: insert.rows[0].id });
  } catch (err) {
    console.error('S3 presign error', err);
    res.status(500).send('Server error');
  }
});

export default router;
EOF

# Backend: create_admin.js
mkdir -p ${ROOT}/backend/scripts
cat > ${ROOT}/backend/scripts/create_admin.js <<'EOF'
/**
 * node create_admin.js email password
 */
import bcrypt from 'bcrypt';
import { Pool } from 'pg';
const [,, email, plain] = process.argv;
if (!email || !plain) { console.error('Usage: node create_admin.js email password'); process.exit(1); }
const pool = new Pool({ connectionString: process.env.DATABASE_URL || 'postgres://grt:grtpassword@localhost:5432/grttravel' });
(async () => {
  const hashed = await bcrypt.hash(plain, 10);
  try {
    const res = await pool.query("INSERT INTO users (id, email, password_hash, full_name, country, created_at) VALUES (gen_random_uuid(), $1, $2, $3, $4, now()) RETURNING id", [email, hashed, 'Admin User', 'IN']);
    console.log('Admin created', res.rows[0].id);
  } catch (err) {
    console.error(err);
  } finally { await pool.end(); }
})();
EOF

# Admin-panel placeholder
cat > ${ROOT}/admin-panel/src/pages/Dashboard.js <<'EOF'
import React from 'react';
export default function Dashboard(){ return (<div style={{padding:20}}><h1>GrtTravel Admin</h1><p>Dashboard placeholder</p></div>); }
EOF

cat > ${ROOT}/admin-panel/package.json <<'EOF'
{
  "name": "grt-admin",
  "private": true,
  "version": "0.1.0",
  "dependencies": { "react": "^18.2.0", "react-dom": "^18.2.0", "@mui/material": "^5.0.0" },
  "scripts": { "start": "react-scripts start", "build": "react-scripts build" }
}
EOF

# DB: schema.sql + schema-extensions (affiliate, attachments)
cat > ${ROOT}/db/schema.sql <<'EOF'
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE,
  password_hash text,
  full_name text,
  country text,
  created_at timestamptz DEFAULT now()
);
CREATE TABLE businesses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  place_id text UNIQUE,
  name text,
  category text,
  address text,
  lat double precision,
  lng double precision,
  approved boolean DEFAULT false,
  featured boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);
CREATE TABLE country_info (
  country_code text PRIMARY KEY,
  name text,
  visa_summary text,
  currency text,
  laws jsonb,
  emergency_numbers jsonb,
  sim_info text,
  updated_at timestamptz DEFAULT now()
);
EOF

cat > ${ROOT}/db/schema-extensions.sql <<'EOF'
-- attachments & affiliate
CREATE TABLE attachments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  entity_type text NOT NULL,
  entity_id uuid,
  filename text NOT NULL,
  url text NOT NULL,
  mime text,
  size_bytes bigint,
  uploaded_by uuid,
  created_at timestamptz DEFAULT now()
);
CREATE TABLE affiliate_partners (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  partner_slug text UNIQUE NOT NULL,
  base_url text NOT NULL,
  notes text,
  created_at timestamptz DEFAULT now()
);
CREATE TABLE affiliate_links (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid REFERENCES businesses(id),
  partner_id uuid REFERENCES affiliate_partners(id),
  affiliate_template text NOT NULL,
  last_updated timestamptz DEFAULT now()
);
CREATE TABLE affiliate_clicks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  affiliate_link_id uuid REFERENCES affiliate_links(id),
  user_id uuid,
  ip text,
  user_agent text,
  referer text,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE businesses ADD COLUMN affiliate_partner_id uuid;
ALTER TABLE businesses ADD COLUMN affiliate_url_template text;
EOF

# DB: country fetcher script
cat > ${ROOT}/db/scripts/fetch_countries.js <<'EOF'
/**
 * Fetch countries and write db/country-full.json, .csv, and .sql
 * Usage: node db/scripts/fetch_countries.js
 */
import https from 'https';
import fs from 'fs';
const API = 'https://restcountries.com/v3.1/all';
function fetchJson(url){ return new Promise((res,rej)=>{ https.get(url, r=>{ let d=''; r.on('data', c=>d+=c); r.on('end', ()=>res(JSON.parse(d))); }).on('error', rej); }); }
function safe(s){ return (s===undefined||s===null)?'':String(s).replace(/'/g,"''"); }
(async ()=> {
  const countries = await fetchJson(API);
  const rows = countries.map(c => {
    const cca2 = c.cca2||'';
    const name = c.name?.common||'';
    const capital = Array.isArray(c.capital)&&c.capital.length?c.capital[0]:'';
    const lat = Array.isArray(c.latlng)&&c.latlng.length?c.latlng[0]:null;
    const lng = Array.isArray(c.latlng)&&c.latlng.length?c.latlng[1]:null;
    const currencies = c.currencies?Object.keys(c.currencies).join(','):'';
    const calling = c.idd?.root?((c.idd.root||'') + (Array.isArray(c.idd.suffixes)?c.idd.suffixes[0]:'')):'';
    const timezones = Array.isArray(c.timezones)?c.timezones.join('|'):'';
    const languages = c.languages?Object.values(c.languages).join(','):'';
    return { country_code: cca2, name, capital, lat, lng, currencies, calling, timezones, languages, region: c.region||'', subregion: c.subregion||'', visa_summary:'', sim_info:'', emergency_numbers: JSON.stringify({police:'', ambulance:'', fire:''}) };
  });
  fs.writeFileSync('db/country-full.json', JSON.stringify(rows,null,2));
  const header = ['country_code','name','capital','lat','lng','currencies','calling','timezones','languages','region','subregion','visa_summary','sim_info','emergency_numbers'].join(',');
  const csv = rows.map(r => [ \`"\${r.country_code}"\`, \`"\${safe(r.name)}"\`, \`"\${safe(r.capital)}"\`, r.lat===null?'':r.lat, r.lng===null?'':r.lng, \`"\${safe(r.currencies)}"\`, \`"\${safe(r.calling)}"\`, \`"\${safe(r.timezones)}"\`, \`"\${safe(r.languages)}"\`, \`"\${safe(r.region)}"\`, \`"\${safe(r.subregion)}"\`, \`"\${safe(r.visa_summary)}"\`, \`"\${safe(r.sim_info)}"\`, \`"\${safe(r.emergency_numbers)}"\` ].join(',')).join('\\n');
  fs.writeFileSync('db/country-full.csv', header + '\\n' + csv);
  const sql = rows.map(r => \`INSERT INTO country_info (country_code, name, visa_summary, currency, laws, emergency_numbers, sim_info, updated_at) VALUES ('\${safe(r.country_code)}','\${safe(r.name)}','\${safe(r.visa_summary)}','\${safe(r.currencies)}', '{}', $$\${r.emergency_numbers}$$, '\${safe(r.sim_info)}', now()) ON CONFLICT (country_code) DO UPDATE SET name = EXCLUDED.name, visa_summary = EXCLUDED.visa_summary, currency = EXCLUDED.currency, emergency_numbers = EXCLUDED.emergency_numbers, sim_info = EXCLUDED.sim_info, updated_at = now();\`; fs.appendFileSync('db/country-full-seed.sql', sql.join('\\n\\n')); 
  console.log('Wrote db/country-full.json, country-full.csv, country-full-seed.sql');
})();
EOF

# Scripts: generate-grt-assets.sh (ImageMagick)
cat > ${ROOT}/scripts/generate-grt-assets.sh <<'EOF'
#!/usr/bin/env bash
# Run from GrtTravel/scripts: ./generate-grt-assets.sh
set -e
BASE="\$(cd "\$(dirname "$0")/.." && pwd)"
SRC="\${BASE}/assets/logo/source/image2.png"
OUT="\${BASE}/assets/logo"
mkdir -p "\${OUT}"
convert "\${SRC}" -trim -background none -alpha on "\${OUT}/grt-hero-transparent.png"
convert "\${OUT}/grt-hero-transparent.png" -resize 1024x1024 -gravity center -extent 1024x1024 "\${OUT}/grt-hero-square.png"
for s in 512 384 256 192 144 96 72 48 32 16; do
  convert "\${OUT}/grt-hero-square.png" -resize "\${s}x\${s}" "\${OUT}/grt-\${s}.png"
done
convert "\${OUT}/grt-hero-transparent.png" -resize 432x432 -gravity center -extent 432x432 "\${OUT}/android-foreground.png"
convert -size 1080x1920 xc:"#0B5FFF" -gravity center -extent 1080x1920 "\${OUT}/android-background.png"
convert "\${OUT}/grt-96.png" -resize 32x32 "\${OUT}/favicon-32.png"
convert "\${OUT}/grt-96.png" -resize 16x16 "\${OUT}/favicon-16.png"
cat > "\${OUT}/monogram.svg" <<SVG
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200">
  <rect width="200" height="200" fill="#0B5FFF"/>
  <text x="100" y="124" font-family="Poppins, Arial" font-size="86" text-anchor="middle" fill="#fff" font-weight="700">GRT</text>
</svg>
SVG
echo "Assets generated at \${OUT}"
EOF
chmod +x ${ROOT}/scripts/generate-grt-assets.sh

# Scripts: bundle_zip.sh
cat > ${ROOT}/scripts/bundle_zip.sh <<'EOF'
#!/usr/bin/env bash
ROOT="GrtTravel"
ZIP="GrtTravel.zip"
if [ -d "\${ROOT}" ]; then
  zip -r "\${ZIP}" "\${ROOT}"
  echo "Created \${ZIP}"
else
  echo "\${ROOT} not found"
fi
EOF
chmod +x ${ROOT}/scripts/bundle_zip.sh

# Scripts: push_release.sh (uses git + gh)
cat > ${ROOT}/scripts/push_release.sh <<'EOF'
#!/usr/bin/env bash
# Usage: ./push_release.sh owner/repo tag "title" "body"
set -e
if [ "$#" -lt 4 ]; then echo "Usage: $0 owner/repo tag \"title\" \"body\""; exit 1; fi
REPO="$1"; TAG="$2"; TITLE="$3"; BODY="$4"
ROOT="../GrtTravel"
ZIP="../GrtTravel.zip"
if [ ! -d "../GrtTravel" ]; then echo "Run create script first"; exit 1; fi
cd "${ROOT}"
if [ ! -d .git ]; then git init; git checkout -b main; fi
git add .; git commit -m "chore: initial scaffold and assets" || true
# ensure remote exists
if ! git remote | grep -q origin; then
  git remote add origin "git@github.com:${REPO}.git"
fi
git push -u origin main
git checkout -b feature/logo || true
git push -u origin feature/logo || true
git checkout main
cd ..
# ensure zip exists
if [ ! -f "${ZIP}" ]; then zip -r "${ZIP}" GrtTravel; fi
gh release create "${TAG}" "${ZIP}" --repo "${REPO}" --title "${TITLE}" --notes "${BODY}"
echo "Release created: https://github.com/${REPO}/releases/tag/${TAG}"
EOF
chmod +x ${ROOT}/scripts/push_release.sh

# .github workflow stub
cat > ${ROOT}/.github/workflows/backend.yml <<'EOF'
name: Backend CI
on: [push]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Setup Node
        uses: actions/setup-node@v4
        with:
          node-version: '18'
      - name: Install backend deps
        run: |
          cd backend
          npm ci || true
EOF

# Docs: deploy-hostinger.md & playstore-checklist
cat > ${ROOT}/docs/deploy-hostinger.md <<'EOF'
Hostinger deployment summary:
- Use Supabase for Postgres (recommended).
- Upload backend to Hostinger Node.js app or deploy to Render if Hostinger plan lacks Node/Postgres.
- Upload admin build (npm run build) to public_html or use Vercel.
- Set env vars in hPanel and never commit secrets.
EOF

cat > ${ROOT}/docs/playstore-checklist.md <<'EOF'
Play Store checklist:
- Pre-permission screen for location (foreground only)
- Privacy policy (HTTPS) and Terms
- High-res 512x512 icon
- Adaptive icon layers
- Android key restricted by package + SHA-1
EOF

# Final bundle
zip -r GrtTravel.zip ${ROOT} >/dev/null
echo "Done. GrtTravel.zip created."
echo ""
echo "Next steps:"
echo "1) Inspect the GrtTravel directory that was created."
echo "2) Generate icons: cd GrtTravel/scripts && ./generate-grt-assets.sh"
echo "3) Optional: fetch countries: node GrtTravel/db/scripts/fetch_countries.js"
echo "4) Optional: apply DB schema to your DATABASE_URL"
echo "5) To push and create GitHub Release: ./GrtTravel/scripts/push_release.sh <owner/repo> v1.0 \"GrtTravel v1.0\" \"Initial scaffold\""
echo "   (gh must be authenticated, and you must have permission to push to the repo)"
echo ""
echo "When you create the Release, paste its URL here and I will review and continue implementing backend/mobile features for you."