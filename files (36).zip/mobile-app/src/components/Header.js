import React from 'react';
import { View, Image, Text, StyleSheet } from 'react-native';

export default function Header() {
  return (
    <View style={styles.container}>
      <Image source={require('../assets/logo/logo-72.png')} style={styles.logo} />
      <Text style={styles.title}>GrtTravel</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flexDirection: 'row', alignItems: 'center', padding: 12 },
  logo: { width: 40, height: 40, marginRight: 10, resizeMode: 'contain' },
  title: { fontSize: 18, fontWeight: '600' }
});