# Play Store Checklist (GR T Travel Guide)

- Pre-permission screen: Explain why location needed (foreground only)
- Privacy Policy URL (must be reachable)
- Terms & Conditions page
- Contact email + phone in listing
- Use only required permission scopes
- OAuth consent verification for Google sign-in (if used)
- Target SDK and manifest configured for foreground-only location