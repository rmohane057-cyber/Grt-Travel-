import React, { useEffect, useState } from 'react';
import { View, Text, Button, Platform } from 'react-native';
import * as Location from 'expo-location';

export default function App() {
  const [location, setLocation] = useState(null);
  const [statusMsg, setStatusMsg] = useState('Requesting location...');

  useEffect(() => {
    (async () => {
      // Explain why location is needed before requesting permission in UI
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setStatusMsg('Location permission denied. Please select city manually.');
        return;
      }

      let loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Highest });
      setLocation(loc);
      setStatusMsg('Location detected.'); // cache this on device (AsyncStorage) in real app
    })();
  }, []);

  return (
    <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
      <Text>{statusMsg}</Text>
      {location && <Text>{JSON.stringify(location.coords)}</Text>}
      <Button title="Manual city selection" onPress={() => {/* navigate to manual city screen */}}/>
    </View>
  );
}