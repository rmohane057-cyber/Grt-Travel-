import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function Settings() {
  const [partners, setPartners] = useState([]);
  const [newPartner, setNewPartner] = useState({ name: '', base_url: '' });

  useEffect(() => {
    axios.get('/api/admin/affiliate-partners').then(r => setPartners(r.data));
  }, []);

  function addPartner() {
    axios.post('/api/admin/affiliate-partners', newPartner).then(r => {
      setPartners([...partners, r.data]);
      setNewPartner({ name: '', base_url: '' });
    });
  }

  return (
    <div style={{ padding: 20 }}>
      <h2>Global Settings</h2>
      <section>
        <h3>Affiliate Partners</h3>
        <div>
          <input placeholder="Name" value={newPartner.name} onChange={e => setNewPartner({...newPartner, name: e.target.value})} />
          <input placeholder="Base URL template" value={newPartner.base_url} onChange={e => setNewPartner({...newPartner, base_url: e.target.value})} />
          <button onClick={addPartner}>Add</button>
        </div>
        <ul>
          {partners.map(p => <li key={p.id}>{p.name} - {p.partner_slug}</li>)}
        </ul>
      </section>
    </div>
  );
}