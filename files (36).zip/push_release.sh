#!/usr/bin/env bash
# push_release.sh
# Usage: ./push_release.sh <github_owner/repo> <tag> "<release_title>" "<release_body>"
# Example: ./push_release.sh rmohane057-cyber/GrtTravel v1.0 "GrtTravel v1.0" "Initial scaffold + logos"
#
# Requires:
# - git installed and configured
# - gh (GitHub CLI) installed and authenticated (gh auth login)

set -e
if [ "$#" -lt 4 ]; then
  echo "Usage: $0 owner/repo tag \"title\" \"body\""
  exit 1
fi

REPO="$1"
TAG="$2"
TITLE="$3"
BODY="$4"

ROOT="GrtTravel"
if [ ! -d "${ROOT}" ]; then
  echo "${ROOT} directory not found. Run create_grttravel_repo_full.sh first."
  exit 1
fi

# Initialize local git repo inside ROOT (or use existing)
cd "${ROOT}"
if [ ! -d .git ]; then
  git init
  git checkout -b main
fi

# Commit everything
git add .
git commit -m "chore: initial scaffold and logos" || echo "Nothing to commit"

# Add remote (if missing)
REMOTE_URL="git@github.com:${REPO}.git"
if ! git remote | grep -q origin; then
  git remote add origin "${REMOTE_URL}"
fi

# Push main
git push -u origin main

# Create feature branches locally and push (logo + init already in main commit)
git checkout -b feature/logo || git checkout feature/logo
git push -u origin feature/logo

git checkout main

# Create release zip (use the already created zip or recreate)
cd ..
ZIP_FILE="GrtTravel.zip"
if [ ! -f "${ZIP_FILE}" ]; then
  zip -r "${ZIP_FILE}" "${ROOT}"
fi

# Create a GitHub release and attach the ZIP (requires gh)
gh release create "${TAG}" "${ZIP_FILE}" --repo "${REPO}" --title "${TITLE}" --notes "${BODY}"
echo "Release ${TAG} created on https://github.com/${REPO}/releases"
echo "Done."
EOF