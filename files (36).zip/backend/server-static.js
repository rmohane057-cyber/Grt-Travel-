const express = require('express');
const path = require('path');
const app = express();

// Serve logo and other static assets
app.use('/static', express.static(path.join(__dirname, 'public')));

// Example: GET /static/assets/logo/logo-192.png will return the file
app.listen(4000);